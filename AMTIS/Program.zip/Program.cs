﻿using System;
using System.Collections.Generic;
using System.Linq;
using Spectre.Console;

namespace DeliveryOptimizer
{
    public record Package(string Name, string From, string To, int Weight);

    public class Bus
    {
        public int Capacity { get; }
        public int CurrentLoad { get; private set; }
        public List<Package> Load { get; } = new();

        public Bus(int capacity) => Capacity = capacity;

        public bool TryLoad(Package pkg)
        {
            if (CurrentLoad + pkg.Weight > Capacity)
                return false;
            Load.Add(pkg);
            CurrentLoad += pkg.Weight;
            return true;
        }

        public List<Package> UnloadAt(string city)
        {
            var toUnload = Load.Where(p => p.To == city).ToList();
            foreach (var p in toUnload)
            {
                Load.Remove(p);
                CurrentLoad -= p.Weight;
            }
            return toUnload;
        }
    }

    public class Graph
    {
        private readonly Dictionary<string, List<(string neighbor, int dist)>> _adj = new();
        private readonly Dictionary<string, Dictionary<string, int>> _distCache = new();

        public void AddEdge(string a, string b, int distance)
        {
            if (!_adj.ContainsKey(a)) _adj[a] = new();
            if (!_adj.ContainsKey(b)) _adj[b] = new();
            _adj[a].Add((b, distance));
            _adj[b].Add((a, distance));
            _distCache.Clear();
        }

        public int ShortestDistance(string start, string end)
        {
            if (start == end) return 0;
            if (!_distCache.TryGetValue(start, out var dist))
            {
                dist = ComputeAllDistances(start);
                _distCache[start] = dist;
            }
            return dist.TryGetValue(end, out var d) ? d : int.MaxValue;
        }

        private Dictionary<string, int> ComputeAllDistances(string start)
        {
            var dist = _adj.Keys.ToDictionary(city => city, _ => int.MaxValue);
            var pq = new PriorityQueue<string, int>();
            dist[start] = 0;
            pq.Enqueue(start, 0);
            while (pq.Count > 0)
            {
                pq.TryDequeue(out var city, out var d);
                if (d > dist[city]) continue;
                foreach (var (nbr, w) in _adj[city])
                {
                    var nd = d + w;
                    if (nd < dist[nbr])
                    {
                        dist[nbr] = nd;
                        pq.Enqueue(nbr, nd);
                    }
                }
            }
            return dist;
        }
    }

    public record RouteStep(string From, string To, List<Package> PickUp, List<Package> DropOff);

    public class Router
    {
        private readonly Graph _graph;
        private readonly Dictionary<string, Queue<Package>> _pickMap;
        private readonly Bus _bus;
        private readonly string _depot;

        public Router(Graph graph, IEnumerable<Package> packages, Bus bus, string depot)
        {
            _graph = graph;
            _bus = bus;
            _depot = depot;
            _pickMap = packages.GroupBy(p => p.From)
                .ToDictionary(g => g.Key, g => new Queue<Package>(g));
        }

        public List<RouteStep> GenerateBasicRoute()
        {
            var route = new List<RouteStep>();
            string current = _depot;
            while (true)
            {
                var drop = _bus.UnloadAt(current);
                var pick = new List<Package>();
                if (_pickMap.TryGetValue(current, out var q))
                {
                    for (int i = 0; i < q.Count; i++)
                    {
                        var pkg = q.Peek();
                        if (_bus.TryLoad(pkg))
                        {
                            pick.Add(pkg);
                            q.Dequeue();
                        }
                        else break;
                    }
                }
                route.Add(new RouteStep(current, current, pick, drop));
                if (!_bus.Load.Any() && _pickMap.Values.All(q => q.Count == 0))
                {
                    if (current != _depot)
                        route.Add(new RouteStep(current, _depot, new(), new()));
                    break;
                }
                var targets = _bus.Load.Any()
                    ? _bus.Load.Select(p => p.To)
                    : _pickMap.Where(kv => kv.Value.Count > 0).Select(kv => kv.Key);
                var next = targets.Distinct()
                    .OrderBy(city => _graph.ShortestDistance(current, city))
                    .First();
                route.Add(new RouteStep(current, next, new(), new()));
                current = next;
            }
            return route;
        }
    }

    internal class Program
    {
        private static void Main()
        {
            AnsiConsole.Write(new FigletText("Delivery Optimizer").Centered().Color(Color.Green));

            var depot = AnsiConsole.Prompt(
                new TextPrompt<string>("[yellow]Enter depot city[/]:")
                    .Validate(s => string.IsNullOrWhiteSpace(s) ? ValidationResult.Error("Depot cannot be empty") : ValidationResult.Success()));

            var graph = new Graph();
            AnsiConsole.MarkupLine("[underline]Enter roads (CityA CityB Distance), type 'END' to finish:[/]");
            while (true)
            {
                var input = AnsiConsole.Prompt(new TextPrompt<string>("[green]Road:[/]").AllowEmpty());
                if (input.Equals("END", StringComparison.OrdinalIgnoreCase)) break;
                var parts = input.Split(' ');
                if (parts.Length == 3 && int.TryParse(parts[2], out var dist))
                    graph.AddEdge(parts[0], parts[1], dist);
                else
                    AnsiConsole.MarkupLine("[red]Invalid format![/] Use CityA CityB Distance.");
            }

            var packages = new List<Package>();
            AnsiConsole.MarkupLine("[underline]Enter packages (Name From To Weight), type 'END' to finish:[/]");
            while (true)
            {
                var input = AnsiConsole.Prompt(new TextPrompt<string>("[green]Package:[/]").AllowEmpty());
                if (input.Equals("END", StringComparison.OrdinalIgnoreCase)) break;
                var parts = input.Split(' ');
                if (parts.Length == 4 && int.TryParse(parts[3], out var w))
                    packages.Add(new Package(parts[0], parts[1], parts[2], w));
                else
                    AnsiConsole.MarkupLine("[red]Invalid format![/] Use Name From To Weight.");
            }

            var capacity = AnsiConsole.Prompt(
                new TextPrompt<int>("[yellow]Enter van capacity[/]:")
                    .Validate(n => n <= 0 ? ValidationResult.Error("Capacity must be positive") : ValidationResult.Success()));

            var bus = new Bus(capacity);
            var route = new Router(graph, packages, bus, depot).GenerateBasicRoute();

            var table = new Table().Border(TableBorder.Rounded).Centered();
            table.AddColumn("Step");
            table.AddColumn("From");
            table.AddColumn("To");
            table.AddColumn("Pick");
            table.AddColumn("Drop");

            int idx = 1;
            foreach (var s in route)
            {
                table.AddRow(
                    idx++.ToString(),
                    s.From,
                    s.To,
                    s.PickUp.Any() ? string.Join(", ", s.PickUp.Select(p => p.Name)) : "-",
                    s.DropOff.Any() ? string.Join(", ", s.DropOff.Select(p => p.Name)) : "-");
            }

            AnsiConsole.WriteLine();
            AnsiConsole.Write(new Panel(table).Header("[bold green]Delivery Route[/]").Expand());
        }
    }
}
